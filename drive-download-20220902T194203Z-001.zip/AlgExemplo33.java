import java.util.Scanner;
public class AlgExemplo33 {

    public static void main (String[]args) {
    	 int cnt = 0;
    	 	double numero, somaNum, dobroNum = 0, media = 0;
    	 somaNum = 0;
    	 Scanner entra = new Scanner(System.in);
    	 while(cnt<5) {
    	 	System.out.println("Numero");
    	 	numero = entra.nextDouble();
    	 	somaNum = somaNum + numero;
    	 	cnt++;
    	 }
    	 media = somaNum/5;
    	 dobroNum = somaNum * 2;
    	 System.out.println("M�dia = " + media);
    	 System.out.println("Dobro = " + dobroNum);

    }


}