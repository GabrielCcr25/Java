import java.util.Scanner;
public class AlgExe55 {
	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);

		String descricao = "aa";
		int quant;
		float precoUnita, compraSoma = 0, compraAtual = 0;

	    System.out.println("O programa ir� parar de rodar quando voc� digitar fim");

		do {
			System.out.println("Digite a descri��o do produto  ");
			ler = new Scanner(System.in);
			descricao = ler.nextLine();

			if(!"fim".equals(descricao)) {
				System.out.println("digite o pre�o do produto e a quantidade que deseja ");
				precoUnita = ler.nextFloat();
				quant = ler.nextInt();

				compraSoma += precoUnita * quant;
				compraAtual = precoUnita * quant;

				System.out.printf("o valor dessa compra � %.2f ", compraAtual);
			}
		} while (!"fim".equals(descricao));

		System.out.printf("o valor total de todas suas compras � de %.2f ", compraSoma);

	}
}