import java.util.Scanner;
public class AlgEXEMPLO34 {

    public static void main ( String[]args ) {

    	Scanner ler = new Scanner(System.in);

    	int num, cnt = 0, somapos = 0, somaneg = 0;



    	while (cnt<10) {
    		System.out.println("Entre com um n�mero");
    	    num = ler.nextInt();



    	if ( num < 0){


    		somaneg += num ;

    	}

    	if (num > 0) {

    		somapos += num ;

    	}
    		cnt++;  }

    	System.out.println("A soma dos n�meros negativos � :" + somaneg);
    	System.out.println("A soma dos n�meros positivos � :" + somapos);



    }


}