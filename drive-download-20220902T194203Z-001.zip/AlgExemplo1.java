


public class AlgExemplo1 {

    public static void main(String[] args) {

    	int a;
    	a = 10;
    	int b = 20;

    	System.out.println("Numero: " + a);
        System.out.println("Numero: " + b);
    }



}
