import java.util.Scanner;
public class Alg55 {

    public static void main (String[]args) {
    	float nota1, nota2, nota3, somaNotaAluno, somaNotaClasse, mediaNotaClasse=0;
    	int quantAprovados=0, quantReprovados=0, quantAlunos=0;
    	string nomeAluno="p";

    	Scanner ler = new Scanner(System.in);

    	while (!nomeAluno.equals("FIM"))
    	{
    		Scanner ler = new Scanner(System.in);
    		System.out.println("Entre com o nome do aluno e digite 'FIM' para encerrar o programa");
    	 	nomeAluno = ler.nextLine();

    	if (!nomeAluno.equals("FIM"))
    	{
    		System.out.println("Entre com as tr�s notas do aluno: ");
    		nota1=ler.nextInt();
    		nota2=ler.nextInt();
    		nota3=ler.nextInt();

    		somaNotaAluno=nota1+nota2+nota3;
    		somaNotaClasse+=somaNotaAluno;
    		quantAlunos++;
    		 if(somaNotaAluno>=60)
    		 	quantAprovados+=1;

    		 else
    		 	quantReprovados-=1
    	}

    	if(quantAlunos>0)
    	{
    		mediaClasse=somaNotaClasse/quantAlunos;
    		System.out.println("A m�dia da classe �: " + mediaClasse);
    		System.out.println("Quantidade de alunos aprovados  : " + quantAprovados);
			System.out.println("Quantidade de alunos reprovados  : " + quantReprovados);
    	}

    	}


    }


}