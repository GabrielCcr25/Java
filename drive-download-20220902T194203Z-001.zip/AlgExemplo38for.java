import java.util.Scanner;
public class AlgExemplo38 {

    public static void main(String[]args) {
    	Scanner ler = new Scanner;
    	int i , num, contpos , contneg, somapos, somaneg;

    	for (i<15, i=0 contpos = 0, contneg=0, somapos = 0, somaneg = 0,num<0,num>0){
    		System.out.println("Entre com n�mero");
    	num = ler.nextInt;
    	i++;
    	}
    	if (num<0) {
    		somaneg+=num;
    		contneg++;
    	}
    	else if (num<0){
    		somapos+=num;
    		contpos++;
    	}
    	else
    		System.out.println("NULO");

    	System.out.println("A quantidade de n�meros positivos �:" + contpos);
    	System.out.println("A quantidade de n�meros negativos �:" + contneg);
        System.out.println("A soma dos positivos �:" + somapos);
     	System.out.println("A soma dos negativos �:" + somaneg);

      }


}