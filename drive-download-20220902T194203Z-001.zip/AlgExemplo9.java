import java.util.Scanner;

public class AlgExemplo9 {

	public static void  (String[] args)  {

		Scanner ler = new Scanner(System.in);

		System.out.println("Calcule a base de um tri�ngulo");
		double base = entrada.nextDouble();
		System.out.println("Calcule a altura de um tri�ngulo");
		double altura = entrada.nextDouble();

        double area = (base*altura) /2;

        System.out.println("A area do triangulo �: " + area);
  }
}