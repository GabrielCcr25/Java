import java.util.Scanner;
public class AlgExemplo13

{
	public static void main(String[] args)
	{

		Scanner ler = new Scanner(System.in);

		float num;

		System.out.println("Entre com um n�mero");
		num = ler.nextFloat();

		if (num > 0)
		System.out.println ("O n�mero � positivo");

	    else if (num == 0)
		System.out.println ("O n�mero � nulo");

		else
		System.out.println ("O n�mero � negativo");

	}
}