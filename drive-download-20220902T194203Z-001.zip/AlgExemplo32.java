
public class AlgExemplo32 {

    public static void main (String[]args) {



        int cnt;
        cnt=100;

        while (cnt<=200){
        	System.out.println(""+cnt);
        	cnt++;
        }
    }


}