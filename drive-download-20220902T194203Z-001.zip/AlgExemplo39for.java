import java.util.Scanner;
public class AlgExemplo39for {

    public static void main(String[]args) {
    	Scanner ler = new Scanner(System.in);

    	int i, num, contPar=0, contImpar=0, somaPar=0, somaImpar=0;

    	for (i=1; i<=10; i++)
    	{
    		System.out.println("Entre com um n�mero");
    		num = ler.nextInt();

	    	if(num!=0)
	    	{
	    		if(num%2==0)
	    		{
	    		   contPar++;
	    		   somaPar+=num;
	    		}
				else
				{
				   contImpar++;
	    		   somaImpar+=num;
	         	}
	    	}
	    	else
	    	{
	    		System.out.println("NUMERO NULO");
	    	}
    	}

        System.out.println("A qtd de n�mero par �:" + contPar);
    	System.out.println("A qtd de numero impar �:" + contImpar);
    	System.out.println("A soma dos pares �:" + somaPar);
    	System.out.println("A soma dos impares �" + somaImpar);

  }


}