import java.util.Scanner;
 public class AlgExemplo36 {
 	public static void main(String[]args);
 	Scanner ler = new Scanner;

  	int idade,cnt = 0 , contmenor21 = 0, contmaior50 = 0;

  	while (cnt<10) {
  		System.out.println("Entre com sua idade")
  			idade = ler.nextInt();
  		cnt++;
  	}
  	if idade<21{
  		contmenor21++
  		}
  	if idade>50{
  		contmaior50++;
  	}
  	System.out.println("A quantidade de pessoas com menos de 21 anos � :" + contmenor21);
  	System.out.println("A quantidade de pessoas com mais de 50 anos � :" +	contmaior50);
  	}

 }