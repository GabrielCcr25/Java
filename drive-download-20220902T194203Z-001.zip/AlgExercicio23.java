import java.util.Scanner;


public class AlgExercicio23 {

    public static void main (String[]args) {

    	Scanner ler = new Scanner(System.in);

    	int valA, valB, valC;

    	System.out.println ("Entre com os valores do tri�ngulo");

    	if (valA == valB == valC)
    		System.out.println("O tri�ngulo � equil�tero");

    	else if (valA == valB | valB == valC | valA == valC)
    		    System.out.println("O tri�ngulo � isosceles");

    	else
    		System.out.println("O tri�ngulo � escaleno");
    }


}