import java.util.Scanner;
public class AlgExemplo12
{
	public static void main(String[] args)
	{
		Scanner ler = new Scanner();

		System.out.println("Entre com um n�mero");

		if > 0;

		System.out.println("O n�mero � positivo");

		else < 0;

		System.out.println("O n�mero � negativo");
	}
}