public class AlgExemplo2 {

    public static void main (String[] args) {
    int a;
    a = 10;
    int b = 20;
    int resultado;

    resultado = a+b;


   System.out.println("Numero: " + a);
   System.out.println("Numero: " + b);
   System.out.println("Os Numeros: " + a + " + " + b + " = " + resultado);
    }


}