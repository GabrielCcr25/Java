public class teste {

    public static void main(String[]args) {

    int i = 1, y ;
	y=i++;

	System.out.println("o valor de 1 ser�:"+ i);
	System.out.println("o valor de y ser�:"+ y);

























    }


}