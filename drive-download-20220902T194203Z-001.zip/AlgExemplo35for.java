import java.util.Scanner;
public class AlgExemplo35 {

    public static void main(string[]args) {
    	Scanner ler = new Scanner(System.in);

	  for (int cnt<10,num, som40 = 0, cnt = 0){
    		System.out.println("Entre com n�mero");
    		num=ler.nextInt();
    	}
    	if {(num<40)
    			som40+=num;
    	}
    	else
    	  System.out.println("O n�mero � maior que 40");

    	  System.out.println("A soma dos n�meros menor que 40 �:" + som40);

    }

 }