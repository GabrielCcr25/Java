import java.util.Scanner;

public class AlgExer�cio7 {

   public static void main (String[] args) {

   	Scanner ler = new Scanner (System.in) ;

   	int a = 30;
   	int b = 15;
   	int resultado;

   	resultado = a - b;

   	System.out.println ("N�mero " + a);
   	System.out.println ("N�mero " + b);
   	System.out.println ("Os N�meros: " + a + " - " + b + " = " + resultado);


   	resultado = a * b;

   	System.out.println ("Os N�meros: " + a + " * " + b + " = " + resultado );
   }

}

