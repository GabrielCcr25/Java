import java.util.Scanner;
public class AlgExemplo35 {

    public static void main(string[]args) {
    	Scanner ler = new Scanner(System.in);

    	int num, som40 = 0, cnt = 0;

    	while (cnt<10){
    		System.out.println("Entre com n�mero");
    		num=ler.nextInt();
    		cnt++
    	}
    	if {(num<40)
    			som40+=num;
    	}
    	else
    	  System.out.println("O n�mero � maior que 40");

    	  System.out.println("A soma dos n�meros menor que 40 �:" + som40);

    }

 }