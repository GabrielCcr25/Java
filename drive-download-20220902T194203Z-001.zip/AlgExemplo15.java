import java.util.Scanner;
public class AlgExemplo15 {

	public static void main(String[] args) {


	Scanner ler = new Scanner(System.in);

	String timeA, timeB;
	int golA, golB;

	System.out.println("Entre com o nome dos times");

	timeA = ler.nextLine();
	timeB = ler.nextLine();

	System.out.println("Entre com os nomes dos times e o placar");

	golA = ler.nextInt();
	golB = ler.nextInt();

	if (golA > golB)
		System.out.println("O time vencedor � : " + timeA);

	else if (golA == golB)
		System.out.println("Empate");

	else
		System.out.println("O time vencedor � : " + timeB);

	}
}