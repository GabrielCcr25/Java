import java.util.Scanner;
public class AlgExemplo49 {

    public static void main(String[]args) {
    	Scanner ler = new Scanner(System.in);
       		int i=50, somaPos=0, contNeg=0;

        while(i!=0) {
        	System.out.println("Entre com um n�mero, para encerrar digite 0");
        	i=ler.nextInt();

        	if(i !=0){

        		if(i>0) {
        		somaPos+=i;

        	}
        	else
        		contNeg++;
        	}

        }

        	System.out.println("A soma dos n�meros positivos �:" + somaPos);
        	System.out.println("A quantidade de n�meros negativos �:" + contNeg);

       }



}