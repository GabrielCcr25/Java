import java.util.Scanner;

public class AlgExemplo10 {

   public static void main(String[] args) {
   		Scanner ler = new Scanner(System.in);

   		float distancia, volume , consumo medio;

   		System.out.println ("Entre com a dist�ncia percorrida");
   		Distancia = ler.NextFloat();
   		System.out.println ("Entre com o volume gasto");
   		Volume = ler.NextFloat();

   		Consumo medio = distancia/volume;

   		System.out.println("O consumo m�dio � : ");


    }


}