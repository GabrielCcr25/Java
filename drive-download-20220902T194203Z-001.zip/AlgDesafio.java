import java.util.Scanner;
public class AlgDesafio {

    public static void main (String[] args) {

    	Scanner entra = new Scanner(System.in);
    	int a, b, aux;

    	System.out.println ("Entre com dois valores");

    	a = entra.nextInt();
    	b = entra.nextInt();

    	aux = a;
    	a = b;
    	b = aux;

    	System.out.println ("Os valores s�o : " + a + " " + b);
    }


}