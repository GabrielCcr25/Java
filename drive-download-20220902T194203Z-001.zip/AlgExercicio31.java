import java.util.Scanner;
public class AlgExercicio31 {

    public static void main(String[]args){
    	int cnt;

    	 while (cnt<=100)
    	 	}
    	 }