import java.util.Scanner;
public class AlgExemplo11
{
	public static void main(String[] args)
	{	Scanner ler = new Scanner(System.in);

		double cfabrica, cconsumidor;
		double porcedis = 12.0;
		double imposto = 45.0;
		double distribuidor, valimpost;

		System.out.println("Informe o custo de fabrica do carro novo");
		cfabrica = Scanner.nextDouble();

		distribuidor = (cfabrica * porcedis)/100.000;
		valimpost = (cfabrica * imposto)/100;
		cconsumidor = (distribuidor + valimpost);

		System.out.println(" O custo ao consumidor de um carro novo � " + consumidor);
	}
}