import java.util.Scanner;
public class AlgExemplo5 {

    public static void main(String[] args) {

    	Scanner ler = new Scanner (System.in);
    	String nome;
    	int idade;
    	float peso;

    	System.out.println ("Entre com o seu nome ");
    	nome = ler.nextLine();

    	System.out.println ("Entre com sua idade ");
    	idade = ler.nextInt();


    	System.out.println ("Entre com seu peso ");
    	peso = ler.nextInt ();


        System.out.println ();
        System.out.println ("Nome: " + nome + " idade: " + idade);
        System.out.printf ("Peso: %.2f ", peso);


    }


}