import java.util.Scanner;
public class AlgExemplo45 {

    public static void main(String[]args) {
    	Scanner ler = new Scanner(System.in);
       		int i=50, somaImpar=0, contPar=0;

        while(i!=-1) {
        	System.out.println("Entre com um n�mero");
        	i=ler.nextInt();

        	if(i !=-1){

        		if(i%2==1) {
        		somaImpar+=i;

        	}
        	else
        		contPar++;
        	}

        }

        	System.out.println("A soma dos n�meros impares �:" + somaImpar);
        	System.out.println("A quantidade de n�meros pares �:" + contPar);

       }



}